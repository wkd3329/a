package aaaaaaa;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
	
public class ds {

	public static String nNo() {
		return (int)(Math.random() * 8999)+1000 +"";
	}
	public static String nId() {
			String text = "";
			String ran = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
			for(int i = 0; i < 6; i++) {
				text += ran.charAt((int)(Math.random() * ran.length()));
			}
			return text;
		}
	public static String nNo2() {
		return (int)(Math.random() * 99)+1 +"";
	}
	
	
	public static void main(String[] args) { // 아이디
		String[] ar={"서울 ","부산 ","대구 ","인천 ","광주 ","대전 ","울산 ","세종 ","경기도 ","강원도 ","충청북도 ","충청남도 ","전라북도 ","전라남도 ","경상북도 ","경상남도 ","제주도 "};
		String[] plat = {"@naver.com","@kakao.com"};
		String[] step = { "매칭신청","배차중","배차완료","소비자 도착","공급자 도착","충전중","매칭종료","매칭종료","매칭종료","매칭종료","매칭종료","매칭종료","매칭종료","매칭종료","매칭종료","매칭종료","매칭종료","매칭종료","매칭종료","매칭종료" };
		double[] grade= {0.1,0.2,0.3,0.4,0.5};
		String[] car = {"기아 EV6","기아 니로","기아 봉고3", "르노삼성 SM3 ZE","MINI 일렉트릭", "벤츠 EQA","벤츠 EQC","벤츠 EQV","벤츠 EQS","볼보 XC","쉐보레 볼트","쌍용 코란도","아우디 E-TRON","제네시스 GV60","제네시스 G80","캐딜락 LYTIQ","테슬라 모델3","테슬라 모델Y","테슬라 모델S","테슬라 모델X","포르쉐 타이칸","현대 아이오닉5","현대 아이오닉6","현대 포터2","현대 코나","BMW I3","BMW IX3","BMW IX"
 } ;
		String[][] arr= {{"종로구","중구","용산구","성동구","광진구","동대문구","중랑구","성북구","강북구","도봉구","노원구","은평구","서대문구","마포구","양천구","강서구","구로구","금천구","영등포구","동작구","관악구","서초구","강남구","송파구","강동구"},{"중구","성구","동구","영도구","부산진구","동래구","남구","북구","해운대구","사하구","금정구","강서구","연제구","수영구","사상구","거장"},{"중구","동구","서구","남구","북구","수성구","달서구","달성"},{"중구","동구","미추홀구","연수구","남동구","부평구","계양구","서구","강화","옹진"},{"동구","서구","남구","북구","광산구"},{"동구","중구","서구","유성구","대덕구"},{"중구","남구","동구","북구","울주"},{ "조치원읍","금남","부강","서종","연기","연동","연서","장","전동","전의","고운동","다정동","대평동","도담동","반곡동","보람동","새롬동","소담동","아름동","종촌동","한솔동","해밀동"},{"고양","수원","용인","과천","광명","광주","구리","군포","김포","남양주","동두천","부천","성남","시흥","안산","산성","안양","양주","여주","오산","의왕","의정부","이천","파주","평택","포천","하남","화성","가평","양평","연천"},{ "강릉","동해","삼척","속초","원주","춘천","태백","고성","양구","양양","영월","인제","정선","철원","평창","홍천","화천","횡성"},{"제천","청주","충주","괴산","단양","보은","영동","옥천","음성","증평","진천"},{"계룡","공주","논산","당진","보령","서산","아산","천안","금산","부여","서천","예산","청양","태안","홍성"},{"군산","김제","남원","익산","전주","정읍","고창","무주","부안","순창","완주","임실","장수","진안구"},{"광양","나주","목포","순천","여수","강진","고흥","곡성","구례","담양","무안","보성","신안","영광","영암","완도","장성","장흥","진도","함평","해남","화순"},{"경산","경주","구미","김천","문경","상주","안동","영주","영천","포항","고령","군위","봉화","성주","영덕", "영양","예천","울릉","울진","의성","청도","청송","칠곡"},{"창원","거제","김해","밀양","사천","양산","진주","통영","거창","고성","남해","산청","의령","창녕","하동","함안","함양","합천"},{"제주시","서귀포"}};
		
		for (int i = 0; i < 100; i++) {
			String plat1="";
			String sql = "insert into MATCH_LOG_TB (match_id, consumer_id, provider_id, match_start_time, consumer_fix_time, consumer_arr_time, provider_arr_time, charge_start_time, charge_end_time, MATCH_END_STEP, consumer_location, provider_location, match_location, charge_amount, charging_fee, consumer_car, provider_charger, consumer_grade, provider_grade) values (";
			String phone = "010"+nNo()+nNo();
			String[] msg= {"동의","거부"};
			String[] road = {"시흥대로",
					"범안로 ",
					"벚꽃로 ",
					"가산로 ",
					"독산로 ",
					"두산로 ",
					"한내로 ",
					"문성로 ",
					"가산로3길 ",
					"방화대로 ",
					"강서로 ",
					"양천로 ",
					"마곡중앙로 ",
					"마곡동로 ",
					"마곡서로 ",
					"등용로 ",
					"만양로 ",
					"매봉로 ",
					"사당로 ",
					"상도로 ",
					"서달로 ",
					"성대로 ",
					"장승배기로 ",
					"흑석로 "};
			String[] name={"ABPrVn89@naver.com",
					"aFzGJr15@kakao.com",
					"AMAEik2@kakao.com",
					"AmflIA2@naver.com",
					"aMoQZw45@kakao.com",
					"arahtE46@naver.com",
					"awbpVp46@naver.com",
					"BbQMOA29@kakao.com",
					"bhWkYd32@naver.com",
					"BiDuzF14@naver.com",
					"bInIrJ39@naver.com",
					"BxEGFh16@naver.com",
					"CDVvek85@kakao.com",
					"cMZYOW51@naver.com",
					"dDvKmA90@kakao.com",
					"deJmqw24@naver.com",
					"EitkKt9@naver.com",
					"eIxUhB91@kakao.com",
					"EniSHK13@kakao.com",
					"eOHHYU51@naver.com",
					"eYzaEz8@naver.com",
					"ffdwLc67@kakao.com",
					"fOSvAZ84@naver.com",
					"ftoRrG77@kakao.com",
					"FvRHMd53@naver.com",
					"FXZumj37@kakao.com",
					"FzmSnZ52@kakao.com",
					"GGAqNa51@kakao.com",
					"GkweEq90@naver.com",
					"GrRfSk3@kakao.com",
					"GrWFyp55@kakao.com",
					"gVEkLZ6@naver.com",
					"gwwrzu78@naver.com",
					"gyGAuW28@naver.com",
					"hPXBQo44@naver.com",
					"HsWznK47@kakao.com",
					"htnQgM23@naver.com",
					"hVdnHq91@naver.com",
					"hyciUq45@naver.com",
					"iDqDoI85@naver.com",
					"IuUIxN50@naver.com",
					"iVGkSs12@naver.com",
					"IWtTto56@naver.com",
					"iZBIeW44@naver.com",
					"IzYkkC31@naver.com",
					"jIGHNR52@naver.com",
					"kaGcmH20@naver.com",
					"KcDblh37@naver.com",
					"KCRmtx57@kakao.com",
					"kCVcoN74@kakao.com",
					"kgivwO47@naver.com",
					"kObDcZ39@naver.com",
					"kRPqfE1@kakao.com",
					"ksKmCO82@kakao.com",
					"lCXKdT2@kakao.com",
					"LDANkE99@kakao.com",
					"LRwvCB2@naver.com",
					"lyurkarl@naver.com",
					"MfgKRd84@naver.com",
					"mTdtbu85@naver.com",
					"mybmKN42@kakao.com",
					"MyPaZN8@naver.com",
					"naBGTa65@kakao.com",
					"nbteOY21@naver.com",
					"nYMyRr59@kakao.com",
					"pDrGwu23@kakao.com",
					"PGaXuV19@kakao.com",
					"pgDGLZ15@naver.com",
					"pKKiuC55@kakao.com",
					"pnepSY16@kakao.com",
					"qDZXdf2@naver.com",
					"qkHaaT44@kakao.com",
					"QyURGY80@kakao.com",
					"qZCQxJ72@naver.com",
					"raTHjP4@kakao.com",
					"RtZXKn21@naver.com",
					"sSlAlR48@naver.com",
					"TDmihj54@naver.com",
					"tlthBq13@naver.com",
					"TQOkpp38@naver.com",
					"TyEAQY37@kakao.com",
					"ufDwMC45@kakao.com",
					"uGbRvk69@kakao.com",
					"uTXLcJ41@naver.com",
					"uYBNvP47@kakao.com",
					"vbFlPK46@kakao.com",
					"VhNNIL2@naver.com",
					"VkTuTA12@kakao.com",
					"vONGNU57@naver.com",
					"vXMqGV21@naver.com",
					"wkd3329@naver.com",
					"WKPhyZ40@naver.com",
					"WYvbRa70@kakao.com",
					"xayHau65@naver.com",
					"XSNsFs5@naver.com",
					"YEzAhz3@naver.com",
					"yUeeRK85@kakao.com",
					"yVHbRH56@naver.com",
					"zautkm16@kakao.com",
					"ZjhJyB18@naver.com",
					"ZtRTYe89@kakao.com",
					"zTufcY29@kakao.com"};
			
			int ran=(int)(Math.random()*17);
			int ran2=(int)(Math.random()*arr[ran].length);
			int ran3=(int)(Math.random()*arr[ran].length);
			int ran4=(int)(Math.random()*arr[ran].length);
			String area1 = ar[ran]+arr[ran][ran2]+" "+road[(int)(Math.random()*road.length)]+(int)(Math.random()*50+1);
			String area2 = ar[ran]+arr[ran][ran3]+" "+road[(int)(Math.random()*road.length)]+(int)(Math.random()*50+1);
			String area3 = ar[ran]+arr[ran][ran4]+" "+road[(int)(Math.random()*road.length)]+(int)(Math.random()*50+1);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-mm-dd hh:mm:ss");
			LocalTime t = LocalTime.now().plusMinutes((int)(Math.random()*3600));	
			LocalTime t1=t.plusMinutes((int)(Math.random()*60));
			LocalTime t2=t1.plusMinutes((int)(Math.random()*60));
			LocalTime t3=t2.plusMinutes((int)(Math.random()*60));
			LocalTime t4=t2.plusMinutes((int)(Math.random()*60));
			LocalTime t5=t3.plusMinutes(60);
			LocalTime t6=t5.plusMinutes((int)(Math.random()*60+10));
			LocalDate ttt=LocalDate.now().minusDays((int)(Math.random()*365));
			String st1 = ttt+" "+t1;
			String st2 = ttt+" "+t2;
			String st3 = ttt+" "+t3;
			String st4 = ttt+" "+t4;
			String st5 = ttt+" "+t5;
			String st6 = ttt+" "+t6;

			int num=i+10700;
			System.out.println(sql+"\""+num+"\",\""+name[(int)(Math.random()*name.length)]+"\",\""+name[(int)(Math.random()*name.length)]+"\",\""+st1+"\",\""+st2+"\",\""+st3+"\",\""+st4+"\",\""+st5+"\",\""+st6+"\",\""+step[(int)(Math.random()*step.length)]+"\",\""+area1+"\",\""+area2+"\",\""+area3+"\",\""+(int)(Math.random()*100+20)+"\",\""+(int)(Math.random()*30000+5000)+"\",\""+ car[(int)(Math.random()*car.length)]+"\",\""+car[(int)(Math.random()*car.length)]+"\",\""+grade[(int)(Math.random()*grade.length)] +"\",\""+grade[(int)(Math.random()*grade.length)]+"\");");             
			
		}
	}
	private static void SimpleDateFormat(String string) {
		// TODO Auto-generated method stub
		
	}
}


