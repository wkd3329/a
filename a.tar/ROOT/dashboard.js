/* globals Chart:false, feather:false */

(function () {
  'use strict'

  feather.replace({ 'aria-hidden': 'true' })

  // Graphs
  var ctx = document.getElementById('myChart')
  // eslint-disable-next-line no-unused-vars

  /*var jan1 = "<%= months[1] %>";
  var feb2 = "<%= months[2] %>";
  var mar3 = "<%= months[3] %>";
  var apr4 =  "<%= month[4] %>";
  var may5 = "<%= months[5] %>";
  var jun6 = "<%= months[6] %>";
  var jul7 = "<%= months[7] %>";
  var aug8 = "<%= months[8] %>";
  var sep9 = "<%= months[9] %>";
  var oct10 = "<%= months[10] %>";
  var nov11 = "<%= months[11] %>";
  var dec12 = "<%= months[12] %>"; */
	
  var myChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: [
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12
      ],
      datasets: [{
        data: [
          1, 2, 3, 4,5
        ],
        lineTension: 0,
        backgroundColor: 'transparent',
        borderColor: '#007bff',
        borderWidth: 4,
        pointBackgroundColor: '#007bff'
      }]
    },
    options: {
      scales: {
        yAxes: [{
          ticks: {
            beginAtZero: false
          }
        }]
      },
      legend: {
        display: false
      }
    }
  })
})()

