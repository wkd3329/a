/* globals Chart:false, feather:false */

//(function () {
//  'use strict'

//  feather.replace({ 'aria-hidden': 'true' })

  // Graphs
  var ctx = document.getElementById('myChart')
  // eslint-disable-next-line no-unused-vars
/*
  var jan = document.getElementsByName('jan')[0].value
  var feb = document.getElementsByName('feb')[0].value
  var mar = document.getElementsByName('mar')[0].value
  var apr = document.getElementsByName('apr')[0].value
  var may = document.getElementsByName('may')[0].value
  var jun = document.getElementsByName('jun')[0].value
  var jul = document.getElementsByName('jul')[0].value
  var aug = document.getElementsByName('aug')[0].value
  var sep = document.getElementsByName('sep')[0].value
  var oct = document.getElementsByName('oct')[0].value
  var nov = document.getElementsByName('nov')[0].value
  var dec = document.getElementsByName('dec')[0].value
  console.log(jan)
*/	
  var myChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: [
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12
      ],
      datasets: [{
        data: [
	    1, 2, 3, 4, 5, 6, 7, 5, 4, 3, 5, 4
//          jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec
        ],
        lineTension: 0,
        backgroundColor: 'transparent',
        borderColor: '#007bff',
        borderWidth: 4,
        pointBackgroundColor: '#007bff'
      }]
    },
    options: {
      scales: {
        yAxes: [{
          ticks: {
            beginAtZero: false
          }
        }]
      },
      legend: {
        display: false
      }
    }
  })

