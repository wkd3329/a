
if(!getCookie('email')){
	alert("로그인이 필요합니다.");
	location.href="login.jsp";

}
else{

	ar ss = sessionStorage.getItem("sUrl");
	ar uu = window.location.href;

	if (ss==null){
		alert("현재 진행중인 충전이 없습니다. 메인화면으로 이동합니다.");
		location.href="main.jsp";
	}
	else if(ss!=uu){
		location.href=ss;
	}

	
}


function getCookie(name) {
  var value = document.cookie.match('(^|;) ?' + name + '=([^;]*)(;|$)');
  return value? value[2] : null;
}
	
